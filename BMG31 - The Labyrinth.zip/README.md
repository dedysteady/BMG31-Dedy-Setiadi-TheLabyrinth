# BMG31 - Dedy Setiadi - The Labyrinth (Blockman Go)

![Downloads](https://img.shields.io/github/downloads/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth/total)
![HitCount](https://hits.dwyl.com/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth.svg?style=flat&show=unique)
![Issues](https://img.shields.io/github/issues/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth)
![Forks](https://img.shields.io/github/forks/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth)
![Stars](https://img.shields.io/github/stars/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth)

This repository for Blockman Go Project and Production Plan from starting the project until finish the project.

## Polishing

Username : Dedysteady
ID : 468553343
Game : The Labyrinth

Link Youtube : [https://youtu.be/AW6qirGmQjs](https://youtu.be/AW6qirGmQjs)

Link Github : [https://github.com/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth/tree/Polishing](https://github.com/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth/tree/Polishing)


