# BMG31 - Dedy Setiadi - The Labyrinth (Blockman Go)

![Downloads](https://img.shields.io/github/downloads/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth/total)
![HitCount](https://hits.dwyl.com/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth.svg?style=flat&show=unique)
![Issues](https://img.shields.io/github/issues/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth)
![Forks](https://img.shields.io/github/forks/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth)
![Stars](https://img.shields.io/github/stars/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth)

This repository for Blockman Go Project and Production Plan from starting the project until finish the project.

