print('script_common:hello world')
Entity.addValueDef("score", 0,true, true, false, true)