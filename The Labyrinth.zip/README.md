# BMG31 - Dedy Setiadi - The Labyrinth (Blockman Go)

![Downloads](https://img.shields.io/github/downloads/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth/total)
![HitCount](https://hits.dwyl.com/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth.svg?style=flat&show=unique)
![Issues](https://img.shields.io/github/issues/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth)
![Forks](https://img.shields.io/github/forks/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth)
![Stars](https://img.shields.io/github/stars/dedysteady/BMG31-Dedy-Setiadi-TheLabyrinth)

This repository for Blockman Go Project and Production Plan from starting the project until finish the project.

## Week 1
Task List Week 1 : https://dedysteady.notion.site/d94656e415424aa490f0fe5b00b83e91?v=fed88c45c4d8409fb16a072d9e885831

Week 1 <br>
Nama fitur: Map & Monster <br>
Rincian fitur:
- Membuat Map Labyrinth pada template Block Template di Blockman Editor <br>
- Membuat Enemy yang bisa menyerang

Tingkat kesulitan: Sedang <br>
Penjelasan: <br>
Agak butuh waktu lagi untuk membuat Map Labyrinth yang menarik dan bagus. Kesulitan di minggu ini lebih ke waktu dan membuat enemy yang dapat menyerang dan menarik. <br>


https://www.notion.so/dedysteady/d94656e415424aa490f0fe5b00b83e91?v=fed88c45c4d8409fb16a072d9e885831
![Screenshot (23)](https://user-images.githubusercontent.com/45990233/186725881-ed986f57-be48-4d47-9147-6e2f291d31cb.png)
![Screenshot (20)](https://user-images.githubusercontent.com/45990233/186725893-b5cde90e-b5ad-4e85-a7f0-30550f58cf90.png)
![Screenshot (21)](https://user-images.githubusercontent.com/45990233/186725922-941da288-2c86-4560-a063-fc335ef3d4c4.png)
